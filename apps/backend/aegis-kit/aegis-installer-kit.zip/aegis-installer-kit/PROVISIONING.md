# Provisioning guide

The order matters. Device ownership (`dpm set-device-owner`) can only be
granted while the device has **no accounts and no secondary users** — so it
happens on a fresh flash, before the arm sequence creates duress/private
profiles.

## 0. Prerequisites

- Workstation with `adb` and `bash`.
- A Pixel flashed with current GrapheneOS (the storefront's flash wizard
  or WebUSB installer produces exactly this state).
- `app-release.apk` built from this repo (see README).
- Optional: the Mullvad VPN APK for always-on lockdown.
- USB debugging enabled on the phone (Settings → About → tap build 7×,
  then Developer options → USB debugging). It gets disabled again by the
  hardening step at the end — that is expected and intended.

## 1. Fresh flash, bare setup

Complete the GrapheneOS setup wizard **without adding any account**.
GrapheneOS never requires one, so this is the natural state after flashing.
If you already added accounts or created users: factory reset and start
over — the DPM grant will otherwise fail.

## 2. Run the script

```bash
cd provision
AEGIS_APK=../app/build/outputs/apk/release/app-release.apk ./provision.sh
```

The script installs the engine, grants device ownership, exempts it from
battery optimization, grants exact-alarm scheduling, turns NFC off at the
OS level, disables the backup manager, optionally installs Mullvad, and
launches the guided setup.

## 3. Guided arm sequence (on the phone)

1. Confirm the "Device ownership verified" banner.
2. Choose triggers & timers (defaults: 3 duress profiles, 8 wrong PINs,
   14-day lock timer, 72 h net-loss, 6-minute reboots).
3. Tick optional hardening (camera/mic, screenshots, wireless-charger
   reboot).
4. Press **ARM AEGIS**.
5. **Write down the recovery sheet** — SMS code, calculator entry, owner
   code are displayed exactly once.

## 4. Set the trap PINs

System → Multiple users: switch into each duress profile once and set its
PIN. Do the same for the private profile. Until this step is done, the
duress profiles exist but have no credentials — the traps are unarmed.

## 5. Validate (sacrificial device only)

Minimum acceptance checklist before any customer device gets this:

- [ ] SMS code from another phone wipes the device.
- [ ] 8 power presses on the lockscreen wipes.
- [ ] Wrong PIN × N wipes (system-enforced).
- [ ] Unlocking a duress profile wipes (measure the latency!).
- [ ] 24 h in airplane mode wipes (net-loss timer).
- [ ] Owner reboots on the 6-minute cadence; private profile does not.
- [ ] Calculator secret switches to the private profile.
- [ ] VAULT icon present after arming; opening it wipes.
- [ ] USB connection offers charging only.
- [ ] Disarm with owner code clears restrictions and stops all wipes.

## Failure modes

- `dpm set-device-owner` fails → accounts/users exist; factory reset.
- Arm report lists skipped restrictions → the OS build did not expose them
  (see FEATURE-MAP confidence column); decide case-by-case.
- Mullvad missing at arm time → VPN lockdown skipped; install Mullvad and
  press "Restart sentinel + timers" in status, then re-arm.

## Going live checklist (storefront integration)

- [ ] Sign release builds with the production keystore.
- [ ] Version-pin against the GrapheneOS release channel you test on.
- [ ] Ship the installer kit (APK + this repo's docs + provision.sh) from
      the fulfillment email after PayPal capture.
- [ ] Support path for "I wiped my own phone / forgot codes" — the answer
      is re-flash + re-arm, and it should be in the FAQ.
