# Aegis Engine

The phone-side half of the Aegis Hardening Suite sold at graphene-security.com.
A device-owner Device Policy Controller (DPC) for GrapheneOS Pixels that
implements duress wipe triggers, automated wipe timers, anti-seizure
countermeasures and lockdown hardening — with **no root and no modification
of the OS image**. Verified boot stays fully intact.

## Architecture

```
┌────────────────────────────────────────────────────────────────┐
│ Aegis Engine (this repo — Kotlin, ~16 files)                   │
│                                                                │
│  WipeEngine ......... the single wipe door (DPM wipeData)      │
│  SentinelService .... quick-wipe · snatch · tamper · net-loss  │
│  BootReceiver ....... battery-removal · high-risk continuation │
│  SmsWipeReceiver .... remote wipe by SMS code                  │
│  DuressManager ...... duress profiles · hidden private profile │
│  RebootScheduler .... 6-minute attack-window cadence            │
│  WatchdogWorker ..... 15-minute fail-closed backstop           │
│  HardeningPolicy .... user restrictions · VPN lockdown          │
│  vault/ ............. VAULT decoy + calculator hidden entry    │
└────────────────────────────────────────────────────────────────┘
        rides on top of GrapheneOS built-ins (profiles, FBE,
        kill-switch support) — it never patches or roots the OS
```

The full feature-by-feature parity matrix against licence-based rivals
lives in **docs/FEATURE-MAP.md**. The honest engineering caveats are
marked `⚠️ VERIFY-ON-HARDWARE` in code and collected in the docs.

## Status

**Source-complete scaffold — not yet hardware-validated.** The code is
written to compile against SDK 35 / minSdk 34 and every risky platform
assumption is behind a guarded call with a log line rather than a crash.
Before shipping to customers:

1. Build it (below) and fix whatever your toolchain disagrees with.
2. Run it on a sacrificial Pixel and work the `⚠️ VERIFY-ON-HARDWARE` list.
3. Re-tune thresholds (`SentinelService` constants) to your test results.

No binary artifacts (keystores, wrapper JAR, APKs) are committed — build
them locally.

## Building

```bash
# Requires JDK 17, Android SDK 35, Gradle 8.9+ (or Android Studio Ladybug+)
cd aegis-engine
gradle wrapper --gradle-version 8.9   # one-time: regenerates gradle/wrapper
./gradlew assembleRelease
# → app/build/outputs/apk/release/app-release.apk
```

Signing: create your keystore and wire it into `app/build.gradle.kts`
`signingConfigs` before release builds go anywhere near a customer device.

## Provisioning a device

See **provision/provision.sh** and **docs/PROVISIONING.md**. Short version:
flash GrapheneOS → finish setup with no accounts → `provision.sh` → the
guided arm sequence on the phone → set duress PINs → verify on a
sacrificial device.

## Repository layout

```
aegis-engine/
├── app/src/main/
│   ├── AndroidManifest.xml        receivers, aliases, FGS declaration
│   ├── res/                        themes, vectors (no binary assets)
│   └── java/com/graphenesecurity/aegis/
│       ├── AegisApp.kt
│       ├── engine/                 12 runtime files
│       ├── hardening/              Restrictions + HardeningPolicy
│       ├── store/Prefs.kt          state + secret hashing
│       ├── ui/                     Setup + Status
│       └── vault/                  VAULT + Calculator decoys
├── docs/                           FEATURE-MAP · THREAT-MODEL · PROVISIONING
├── provision/provision.sh
├── LICENSE-NOTES.md
└── (gradle files)
```

## Licence

Copyright (c) 2025 Privacy Store Ltd. Distributed to Aegis licensees for
audit and rebuild. See LICENSE-NOTES.md for the bundled-components notice
(Mullvad is GPL-3.0 and must stay unmodified and separately distributed).
