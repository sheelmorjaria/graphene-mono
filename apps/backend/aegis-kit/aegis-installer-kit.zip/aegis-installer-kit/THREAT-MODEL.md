# Threat model

## What Aegis defends

The device and its data against **physical seizure** by an adversary who
holds the hardware: street snatch, detention, border seizure, forced
handover, confiscation. The protection is data destruction, not data
denial: the assumption is that hardware in an adversary's hands is
eventually openable, so the data must not survive long enough to matter.

Secondary: opportunistic extraction attempts (cable tools, charger
attacks, rogue media) against a device that is briefly unattended or
locked.

## What it does NOT defend

- **Rubber-hose cryptanalysis.** A motivated adversary with the owner
  present can compel the owner to unlock. Duress PINs raise the cost
  (any unlock might be the trap) but cannot eliminate coercion.
- **Zero-click exploitation of a live, unlocked session.** The 6-minute
  reboot cadence bounds the window; it does not close it.
- **State-level forensics on powered-down hardware.** GrapheneOS FBE
  provides the at-rest guarantee; Aegis's job is to make sure the
  ciphertext never gets old enough to be worth chip-off.
- **An adversary who owns the device legitimately** (warranty return,
  resale). Disarm requires the owner code; re-flashing the phone destroys
  the data anyway, which is the intended behaviour.

## Adversary capabilities assumed

| Capability | Aegis response |
|---|---|
| Brute-force the lockscreen | wrong-PIN wipe + duress profile traps |
| Keep the device in a Faraday bag | network-loss timer |
| Simply wait / detain the device | lock timer |
| Pull power to stop timers | heartbeat + power-loss detection at next boot |
| Chill the device (cold boot) / voltage glitch | temperature & voltage watchdog → reboot to locked |
| Use cable extraction tools | charge-only USB, debugging disabled |
| Fake cell tower / downgrade to 2G | 2G restriction |
| Read the screen later, record it | screenshot restriction (optional) |
| Look for "hidden files" on the everyday profile | VAULT decoy wipes |
| Force the owner to unlock | duress PINs (imperfect, documented) |

## Fail-safe direction

Every trigger fails **toward wiping** when the engine cannot get state
(e.g. unknown foreground user → treat as owner → keep the reboot cadence).
The exceptions are equally deliberate: `wipe()` itself refuses to run when
the engine is not armed or not device owner, so a half-installed or
demoted engine can never destroy data by accident.

## Residual risks we accept and document

- The everyday profile sees the Aegis notification. Stealth is not
  claimed; deterrence is.
- Wipe thresholds are user-tunable. A customer who sets a 1-hour
  net-loss timer will wipe their own phone on a long flight — the setup
  screen warns, but the tool obeys.
