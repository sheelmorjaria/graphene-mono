# Aegis Feature Map — implementation vs. claims

Every defense the storefront advertises, mapped to the mechanism that
implements it and the confidence level. **H** = public API, expected to work
as written. **V** = needs verification on real GrapheneOS hardware (flagged
`⚠️ VERIFY-ON-HARDWARE` in code). **A** = approximation by design, documented
honestly.

## 1. Self-wipe triggers

| Storefront claim | Mechanism | Confidence |
|---|---|---|
| Trigger a self wipe | `DevicePolicyManager.wipeData(WIPE_EXTERNAL_STORAGE)` from the device owner | H |
| Multiple duress PINs | Duress = dedicated secondary profiles created via `createAndManageUser`; each has its own lockscreen credential. Unlocking INTO one is the duress event. | **A/V** — the engine cannot see the lockscreen PIN pad; profile-foreground detection is broadcast + reflection-poll based (`DuressManager`) |
| Quick wipe — 8 power presses | SCREEN_ON/OFF event burst counting while keyguard engaged (`SentinelService.QuickWipeCounter`) | **V** — press-to-event mapping and broadcast delivery cadence need hardware tuning |
| Remote wipe by SMS | `SmsWipeReceiver` + self-granted RECEIVE_SMS; SHA-256 compared code | H |

## 2. Automated wipes

| Claim | Mechanism | Confidence |
|---|---|---|
| Lock timer (not unlocked in N days) | USER_PRESENT stamps `lastUnlockMs`; exact alarm + 15-min watchdog check the deadline | H |
| Network-loss timer (Faraday bag) | NetworkCallback over raw transports (Wi-Fi/cell/ethernet, never VPN); persisted offline state drives the deadline | H (airplane mode counts — intended) |
| Wrong-PIN wipe after N attempts; blank not counted | `setMaximumFailedPasswordsForWipe(N)` — the platform enforces it and does its own blank-input filtering | H |

## 3. Anti-adversary countermeasures

| Claim | Mechanism | Confidence |
|---|---|---|
| Anti-snatch lock | Accelerometer magnitude spike → `lockNow()`; armed only while screen interactive | **V** — threshold (30 m/s²) needs field tuning |
| VAULT decoy app | Launcher alias, disabled until armed; opening it calls `wipeData` | H |
| Battery-removal protection | ACTION_SHUTDOWN flag + persisted heartbeat; boot compares gap vs tolerance and detects clock-backwards (RTC reset) | **V** — PMIC RTC behavior on Pixels after battery disconnect must be measured |
| Temperature & voltage monitoring → reboot | BATTERY_CHANGED: <0°C / >45°C / >4.6V → `DPM.reboot()` with cooldown | H (thresholds need tuning) |
| Attack window: owner auto-reboot every 6 min | Exact-alarm cadence → `DPM.reboot()`; private profile exempt; high-risk mode takes precedence | H |
| Wireless charger detection → reboot (optional) | BATTERY_CHANGED `BATTERY_PLUGGED_WIRELESS` | H |
| High-risk mode bootloop | armed window → every boot posts fault notification and schedules a 45s reboot; 1-min tick checks expiry → self-recovery | H |

## 4. Security hardening

| Claim | Mechanism | Confidence |
|---|---|---|
| Safe boot disabled | `DISALLOW_SAFE_BOOT` user restriction | **V** (restriction key resolved by reflection) |
| Developer mode disabled | `DISALLOW_DEBUGGING_FEATURES` | H |
| USB charge-only | `DISALLOW_USB_FILE_TRANSFER` | **V** — MTP/PTP gating scope; ADB is separately killed by the same debugging restriction |
| Screenshots/recording disabled (optional) | `setScreenCaptureDisabled(admin, true)` | **V** — per-user scope on GrapheneOS |
| Camera & mic disabled (optional) | `setCameraDisabled` + `DISALLOW_UNMUTE_MICROPHONE` | **V** — mic restriction is profile-scoped on AOSP |
| Physical media mount disabled | `DISALLOW_MOUNT_PHYSICAL_MEDIA` | **V** |
| 2G blocked / LTE only | `DISALLOW_CELLULAR_2G` (API 34) | H |
| NFC disabled | no DPM API — `svc nfc disable` in provisioning | **A** — quick-settings re-enable is possible; re-run provision after resets |
| Backups disabled | `DISALLOW_BACKUP` + `bmgr enable false` at provision + `allowBackup=false` in manifest | **V** |
| No installs on Owner profile | `DISALLOW_INSTALL_APPS` + `DISALLOW_INSTALL_UNKNOWN_SOURCES` + permission-policy DENY | **V** — restriction scope (owner-only vs global) on device owner |

## 5. Private profile & network

| Claim | Mechanism | Confidence |
|---|---|---|
| Private profile | secondary user via `createAndManageUser`; invisible to the everyday profile's app list and switcher | H |
| Hidden login via calculator | working calculator decoy; secret sequence hashed, `=` submits; `DPM.switchUser` on match | H |
| Locked-down settings | `DISALLOW_USER_SWITCHING` on the everyday profile; no Aegis surface there (launcher alias hidden after arm) | **V** |
| VPN kill switch | `setAlwaysOnVpnPackage(admin, "net.mullvad.vpn", lockdownEnabled=true)` | H |

## Known gaps (do not paper over these)

1. **Duress detection latency.** If neither USER_FOREGROUND nor the
   reflection poll is delivered on a given build, the watchdog still catches
   a duress unlock within 15 minutes — but that is far from instant. The
   hardware test must measure actual latency.
2. **NFC re-enable.** `svc nfc disable` is not tamper-proof. If quick
   settings exposes the tile on the everyday profile, it can be toggled
   back. Long-term fix: a GrapheneOS feature request, not a workaround.
3. **Everything marked V in the tables above** is implemented with guarded
   calls that log-and-continue. The arm report screen lists every item that
   did not stick, so a customer is never silently under-protected.
