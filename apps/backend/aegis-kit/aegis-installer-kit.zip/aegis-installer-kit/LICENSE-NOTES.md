# Licence notes

## Aegis Engine

Copyright (c) 2025 Privacy Store Ltd. All rights reserved.

Distributed to Aegis Hardening Suite licensees for audit, review and
rebuild. Licensees may modify and rebuild for use on their own licensed
devices. Redistribution of the engine, its APK, or derivative works to
third parties who have not purchased an Aegis license is not permitted.

The storefront price of the Aegis Hardening Suite is primarily a service
and curation charge (provisioning, hardening profiles, curated open-source
stack, support); the engine is the automation layer on top of the
GrapheneOS platform's own security architecture.

## Bundled / referenced third-party components

The engine **does not vendor or modify any third-party code**. It
configures components installed alongside it:

- **Mullvad VPN** (`net.mullvad.vpn`) — GPL-3.0. Installed as an unmodified
  separate APK during provisioning and configured through the public
  Android always-on-VPN interface. No linking, no modification; GPL
  obligations stay with its own distribution.
- **GrapheneOS** — MIT-licensed platform. The engine is a user-space
  configuration layer and contains no GrapheneOS code.
- **Android/GrapheneOS platform APIs** — used through documented
  DevicePolicyManager surfaces; hidden-API use is limited to guarded
  reflection lookups (see `Restrictions.kt`, `DuressManager.kt`) that fail
  closed with a log line.

If you redistribute a build of this engine, keep this notice and the
README's provenance section intact.
