#!/usr/bin/env bash
#
# Aegis Engine — device-owner provisioning
#
# Runs on a workstation with adb, against a freshly flashed GrapheneOS Pixel
# that has completed the initial setup wizard WITHOUT adding any account
# (GrapheneOS never requires one). Device ownership can only be granted while
# no accounts and no secondary users exist — so run this BEFORE the guided
# arm sequence creates duress/private profiles.
#
# Usage:
#   ./provision.sh                    # install + set device owner + hardening
#   AEGIS_APK=../app/build/outputs/apk/release/app-release.apk ./provision.sh
#
set -euo pipefail

PKG="com.graphenesecurity.aegis"
ADMIN="${PKG}/.engine.AegisDeviceAdminReceiver"
AEGIS_APK="${AEGIS_APK:-../app/build/outputs/apk/release/app-release.apk}"
MULLVAD_APK="${MULLVAD_APK:-./mullvad-latest.apk}"   # optional; VPN lockdown

say() { printf '\033[0;32m[aegis]\033[0m %s\n' "$*"; }
die() { printf '\033[0;31m[aegis]\033[0m %s\n' "$*" >&2; exit 1; }

command -v adb >/dev/null || die "adb not found in PATH"
adb get-state >/dev/null 2>&1 || die "no device connected — enable USB debugging and re-run"

say "installing Aegis engine"
adb install -r "$AEGIS_APK"

say "granting device ownership (fresh flash, no accounts/users expected)"
adb shell dpm set-device-owner "$ADMIN" \
  || die "dpm set-device-owner failed — wipe/reflash the device first (accounts or users already exist)"

# --- reliability grants ------------------------------------------------------
say "battery-optimization exemption + exact alarms"
adb shell dumpsys deviceidle whitelist "+${PKG}" || true
adb shell pm grant "${PKG}" android.permission.SCHEDULE_EXACT_ALARM || true

# --- OS-level toggles that DPM cannot reach ----------------------------------
# NFC has no user-restriction; svc persists the state across reboots.
# Re-run after any OS reset if quick-settings shows NFC re-enabled.
say "disabling NFC (svc)"
adb shell svc nfc disable || true

# Backup manager off for the user — belt and braces on top of DISALLOW_BACKUP.
say "disabling backup manager"
adb shell bmgr enable false || adb shell bmgr enabled false || true

# --- optional: Mullvad for always-on VPN lockdown -----------------------------
if [[ -f "$MULLVAD_APK" ]]; then
  say "installing Mullvad VPN"
  adb install -r "$MULLVAD_APK"
else
  say "MULLVAD_APK not found — skipping VPN install (arm again after installing it)"
fi

# --- launch the guided arm sequence -------------------------------------------
say "starting guided setup"
adb shell am start -n "${PKG}/.ui.SetupActivity"

say "PROVISIONED. Now:"
say "  1. Follow the on-screen arm sequence (choose toggles, write down the recovery sheet)."
say "  2. Set a PIN for each duress profile: System -> Multiple users."
say "  3. Set the private profile PIN the same way, then verify the Calculator entry."
say "  4. Test ONE wipe path on a sacrificial device before trusting the fleet."
